package com.aadevelopers.cashkingapp

interface OnVideoAdEnded {
    fun videoWatched()
}
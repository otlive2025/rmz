package com.aadevelopers.cashkingapp

interface OnScratchComplete {
    fun onComplete()
}
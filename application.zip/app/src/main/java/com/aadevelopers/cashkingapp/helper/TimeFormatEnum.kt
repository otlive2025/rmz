package com.aadevelopers.cashkingapp.helper

enum class TimeFormatEnum {
    MILLIS, SECONDS, MINUTES, HOUR, DAY;
}